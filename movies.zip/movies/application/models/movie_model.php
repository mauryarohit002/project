<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class movie_model extends CI_Model{

	function insert($table,$data){
		return $this->db->insert($table,$data);
		
	}

	function getwheredb($table,$data){
		// print_r($data);
		$this->db->where($data);
		$query=$this->db->get($table);
		 // print_r($query);
		 if($query->num_rows()>0){
		 	$this->db->where($data);
			return $this->db->get($table)->result_array();

		 }
		 else{
		 	return "error";
		 }
	}

	function getdb($table){
		return $this->db->get($table)->result_array();
	}

	function getselectdb($data){
		$this->db->select('movie_screen.*,screen.s_id,screen.s_name,theater.th_id,theater.th_name');
		$this->db->from('movie_screen');
		$this->db->where('ms_movieid',$data['m_id']);
		$this->db->join('screen','screen.s_id=movie_screen.ms_screenid');
		$this->db->join('theater','theater.th_id=screen.s_thid');
		$query=$this->db->get();
		if($query->num_rows()>0){
			return$res=$query->result_array();
			// print_r($res);
		}
	}

	function selectlikedb($data){
		 //return$this->db->select('*')->from('movie')->like('m_name',$data)->get()->result_array();
		return$res=$this->db->query('SELECT * FROM movie WHERE m_name LIKE "'.$data.'%"')->result_array();
		 
	}

	
}