<?php 
  $this->load->view('nav');
 ?>
<div id="content-wrapper">

        <div class="container-fluid">

          <!-- Breadcrumbs-->
          <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="#">Dashboard</a>
            </li>
            <li class="breadcrumb-item active">Overview</li>
          </ol>
          <div class="container">
            <div class="row">
              <div class="col-sm-4">
                  <img src="<?php echo base_url($movie[0]['img_path']); ?>" />
                  <h2><?php echo $movie[0]['m_name'] ?></h2>
                  <p><?php echo $movie[0]['m_desc'] ?></p>
                  <p>Theater name : <?php echo $thtr[0]['th_name'] ?></p>
                  <p>Screen name : <?php echo $scrn[0]['s_name'] ?></p>
              </div>
              <div class="col-sm-8">
                <form id="formRecord" name="formRecord" method="post" action="">
                  <?php  
                  //$res_screen = $obj->get_seats_by_screen_id($_GET['sid']);
                  // print_r($res_screen);
                  // print_r(date('Y-m-d'));

                  if(is_array($sts)):
                    foreach($sts as $val_sts):
                      //$cntt = $obj->check_seat_exist($mid,$_GET['sid'],$_GET['thid'],date('Y-m-d'),$val_sts['se_no']);                       
                      //print_r($cntt);
                      

                      if($uorder[0]['odate']==date('Y-m-d') && $uorder[0]['oscreenid']==$scrn[0]['s_id'] && $uorder[0]['omovieid']==$movie[0]['m_id'] && $uorder[0]['othid']==$thtr[0]['th_id'] && $uorder[0]['oseatno']==$val_sts['se_no']){
                  ?>
                  <div class="seats_blocked">
                    <span class="seatno"><?php echo $val_sts['se_no']; ?></span>
                    <br>
                    <span class="seatamount"><?php echo $val_sts['se_amount']; ?></span>
                  </div>
                  
                  <?php  
                     }

                    else{
                  ?>
                  <div class="seats">
                    <span class="seatno"><?php echo $val_sts['se_no']; ?></span>
                    <br>
                    <span class="seatamount"><?php echo $val_sts['se_amount']; ?></span>
                  </div>
                  <?php  
                    }

                    endforeach;
                    endif;
                  ?>

                  <div class="clearfix"></div>

                  
                    
                    <h4 style="display: inline-block;">Dates:</h4>
                    <?php 
                    
                    // print_r();
                    $start = $mscrn[0]['ms_startdate'];
                     // var_dump($start);
                    $end = $mscrn[0]['ms_enddate'];

                    $diff=  date_diff(date_create($end),date_create($start));
                    // print_r($diff);
                    // echo $diff->d;

                    if($diff->d > 0){
                        $cnt=0;
                         echo "<select name='date_selected'>";
                        
                        for($i=1;$i<=$diff->d+1;$i++){
                          // echo $i;
                          $newdate = date('Y-m-d', strtotime($start . "+$cnt day"));
                          if($newdate >= date('Y-m-d')):
                           echo "<option value='".$newdate."'>".$newdate."</option>";
                          echo "<span class='dateclass'>";
                          echo $newdate;
                          echo "</span>";
                        endif;
                          $cnt++;
                        }
                     

                       echo "</select>";
                    }
                    ?>

                    <!-- <input type="hidden" class="date_selected" name="date_selected" value="<?php echo date('Y-m-d');?>"> -->
                    <input type="hidden" name="screenid" value="<?php echo $scrn[0]['s_id']?>">
                    <input type="hidden" name="movieid" value="<?php echo $movie[0]['m_id']?>">
                    <input type="hidden" name="theaterid" value="<?php echo $thtr[0]['th_id']?>">

                    <input type="hidden" name="seatno" class="seatNo">
                    <input type="hidden" name="seatamount" class="seatAmount">
                    <input type="hidden" name="totalamount" class="totalAmount">

                    <button class="add_final_seats btn btn-block">Submit</button>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>

        <a href="#" class="adata">CLICK</a>
        <!-- /.container-fluid -->

        <style type="text/css">
          .seats{
            width:80px;height:80px;
            background:#eee;
            float:left;
            margin:10px;
            padding:5px;
            border-radius:10px;
            box-shadow: 1px 2px 4px #777;
            text-align: center;
            cursor: pointer;
          }
          .seats_blocked{
            width:80px;height:80px;
            background:#f00;
            float:left;
            margin:10px;
            padding:5px;
            border-radius:10px;
            box-shadow: 1px 2px 4px #777;
            text-align: center;
            cursor: pointer;
          }
          .greenClass{
            background: #090;
          }
          .dateclass{
            display: inline-block;
            padding:20px;
            background: #eee;
            border:1px solid;
            margin:10px;
          }
        </style>
   <?php 
      $this->load->view('footer');
    ?>     