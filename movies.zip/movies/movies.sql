-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 13, 2018 at 12:12 PM
-- Server version: 5.6.20
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `movies`
--

-- --------------------------------------------------------

--
-- Table structure for table `area`
--

CREATE TABLE IF NOT EXISTS `area` (
`aid` int(11) NOT NULL,
  `aname` varchar(250) NOT NULL,
  `acid` int(100) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `area`
--

INSERT INTO `area` (`aid`, `aname`, `acid`) VALUES
(3, 'andheri', 1),
(4, 'wagle state', 2);

-- --------------------------------------------------------

--
-- Table structure for table `city`
--

CREATE TABLE IF NOT EXISTS `city` (
`cid` int(11) NOT NULL,
  `cname` varchar(250) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `city`
--

INSERT INTO `city` (`cid`, `cname`) VALUES
(1, 'mumbai'),
(2, 'thane'),
(3, 'navi mumbai');

-- --------------------------------------------------------

--
-- Table structure for table `movie`
--

CREATE TABLE IF NOT EXISTS `movie` (
`m_id` int(11) NOT NULL,
  `m_name` varchar(255) NOT NULL,
  `img_path` varchar(255) NOT NULL,
  `m_desc` varchar(255) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `movie`
--

INSERT INTO `movie` (`m_id`, `m_name`, `img_path`, `m_desc`) VALUES
(1, 'zero', 'assets/uploads/Zero_official_poster_small.jpg', 'Zero is an upcoming 2018 Indian Hindi-language romantic drama film, written by Himanshu Sharma and directed by Aanand L. Rai. It was jointly produced by Colour Yellow Productions and Red Chillies Entertainment''s Gauri Khan, and stars Shah Rukh Khan, Anush'),
(2, 'simmba', 'assets/uploads/simmba.jpg', 'Simmba is an orphan from Shivgadh from where our beloved Singham was born and raised. Contrary to the philosophies of Singham, Simmba believes that a Corrupt Officer''s life is an ideal life which inspires him to become one.');

-- --------------------------------------------------------

--
-- Table structure for table `movie_screen`
--

CREATE TABLE IF NOT EXISTS `movie_screen` (
`ms_id` int(11) NOT NULL,
  `ms_movieid` int(11) NOT NULL,
  `ms_screenid` int(11) NOT NULL,
  `ms_startdate` date NOT NULL,
  `ms_enddate` date NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `movie_screen`
--

INSERT INTO `movie_screen` (`ms_id`, `ms_movieid`, `ms_screenid`, `ms_startdate`, `ms_enddate`) VALUES
(1, 1, 1, '2018-12-10', '0000-00-00'),
(2, 1, 1, '2018-12-11', '2018-12-18'),
(3, 1, 2, '2018-12-11', '2018-12-22'),
(4, 2, 2, '2018-12-13', '2018-12-21');

-- --------------------------------------------------------

--
-- Table structure for table `muser`
--

CREATE TABLE IF NOT EXISTS `muser` (
`uid` int(100) NOT NULL,
  `uname` varchar(250) NOT NULL,
  `umobile` varchar(100) NOT NULL,
  `uemail` varchar(250) NOT NULL,
  `upass` varchar(250) NOT NULL,
  `ustatus` enum('0','1','','') NOT NULL DEFAULT '0'
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `muser`
--

INSERT INTO `muser` (`uid`, `uname`, `umobile`, `uemail`, `upass`, `ustatus`) VALUES
(1, 'rom', '8286850973', 'rom@gmail.com', '7110eda4d09e062aa5e4a390b0a572ac0d2c0220', '0'),
(2, 'chirag', '8769054876', 'chiru@gmail.com', '8cb2237d0679ca88db6464eac60da96345513964', '0');

-- --------------------------------------------------------

--
-- Table structure for table `screen`
--

CREATE TABLE IF NOT EXISTS `screen` (
`s_id` int(11) NOT NULL,
  `s_name` varchar(250) NOT NULL,
  `s_thid` int(11) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `screen`
--

INSERT INTO `screen` (`s_id`, `s_name`, `s_thid`) VALUES
(1, 'screen A', 1),
(2, 'screen A', 2),
(3, 'screen B', 2);

-- --------------------------------------------------------

--
-- Table structure for table `seat`
--

CREATE TABLE IF NOT EXISTS `seat` (
`se_id` int(11) NOT NULL,
  `se_amount` int(11) NOT NULL,
  `se_no` int(11) NOT NULL,
  `se_screenid` int(11) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=49 ;

--
-- Dumping data for table `seat`
--

INSERT INTO `seat` (`se_id`, `se_amount`, `se_no`, `se_screenid`) VALUES
(4, 100, 1, 1),
(5, 100, 2, 1),
(6, 100, 3, 1),
(7, 100, 4, 1),
(8, 100, 5, 1),
(9, 100, 6, 1),
(10, 100, 7, 1),
(11, 100, 8, 1),
(12, 100, 9, 1),
(13, 100, 10, 1),
(14, 150, 11, 2),
(15, 150, 12, 2),
(16, 150, 13, 2),
(17, 150, 14, 2),
(18, 150, 15, 2),
(19, 150, 16, 2),
(20, 150, 17, 2),
(21, 150, 18, 2),
(22, 150, 19, 2),
(23, 150, 20, 2),
(24, 150, 11, 1),
(25, 150, 12, 1),
(26, 150, 13, 1),
(27, 150, 14, 1),
(28, 150, 15, 1),
(29, 100, 1, 2),
(30, 100, 2, 2),
(31, 100, 3, 2),
(32, 100, 4, 2),
(33, 100, 5, 2),
(34, 100, 6, 2),
(35, 100, 7, 2),
(36, 100, 8, 2),
(37, 100, 9, 2),
(38, 100, 10, 2),
(39, 150, 11, 2),
(40, 150, 12, 2),
(41, 150, 13, 2),
(42, 150, 14, 2),
(43, 150, 15, 2),
(44, 150, 16, 2),
(45, 150, 17, 2),
(46, 150, 18, 2),
(47, 150, 19, 2),
(48, 150, 20, 2);

-- --------------------------------------------------------

--
-- Table structure for table `theater`
--

CREATE TABLE IF NOT EXISTS `theater` (
`th_id` int(11) NOT NULL,
  `th_name` varchar(250) NOT NULL,
  `th_areaid` int(100) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `theater`
--

INSERT INTO `theater` (`th_id`, `th_name`, `th_areaid`) VALUES
(1, 'sangum', 3),
(2, 'chiru', 4);

-- --------------------------------------------------------

--
-- Table structure for table `userorder`
--

CREATE TABLE IF NOT EXISTS `userorder` (
`oid` int(11) NOT NULL,
  `odate` date NOT NULL,
  `oscreenid` int(11) NOT NULL,
  `omovieid` int(11) NOT NULL,
  `othid` int(11) NOT NULL,
  `oseatno` int(11) NOT NULL,
  `oamount` int(11) NOT NULL,
  `ouid` int(11) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `userorder`
--

INSERT INTO `userorder` (`oid`, `odate`, `oscreenid`, `omovieid`, `othid`, `oseatno`, `oamount`, `ouid`) VALUES
(1, '2018-12-12', 1, 1, 1, 1, 1, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `area`
--
ALTER TABLE `area`
 ADD PRIMARY KEY (`aid`);

--
-- Indexes for table `city`
--
ALTER TABLE `city`
 ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `movie`
--
ALTER TABLE `movie`
 ADD PRIMARY KEY (`m_id`);

--
-- Indexes for table `movie_screen`
--
ALTER TABLE `movie_screen`
 ADD PRIMARY KEY (`ms_id`);

--
-- Indexes for table `muser`
--
ALTER TABLE `muser`
 ADD PRIMARY KEY (`uid`);

--
-- Indexes for table `screen`
--
ALTER TABLE `screen`
 ADD PRIMARY KEY (`s_id`);

--
-- Indexes for table `seat`
--
ALTER TABLE `seat`
 ADD PRIMARY KEY (`se_id`);

--
-- Indexes for table `theater`
--
ALTER TABLE `theater`
 ADD PRIMARY KEY (`th_id`);

--
-- Indexes for table `userorder`
--
ALTER TABLE `userorder`
 ADD PRIMARY KEY (`oid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `area`
--
ALTER TABLE `area`
MODIFY `aid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `city`
--
ALTER TABLE `city`
MODIFY `cid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `movie`
--
ALTER TABLE `movie`
MODIFY `m_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `movie_screen`
--
ALTER TABLE `movie_screen`
MODIFY `ms_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `muser`
--
ALTER TABLE `muser`
MODIFY `uid` int(100) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `screen`
--
ALTER TABLE `screen`
MODIFY `s_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `seat`
--
ALTER TABLE `seat`
MODIFY `se_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=49;
--
-- AUTO_INCREMENT for table `theater`
--
ALTER TABLE `theater`
MODIFY `th_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `userorder`
--
ALTER TABLE `userorder`
MODIFY `oid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
