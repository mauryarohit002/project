<?php 
$this->load->view('header');
 ?>

<div class="container-fluid">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<h2>Sent <span>SMS</span></h2>
				<p><a href="<?php echo base_url('index.php/rom/send_sms'); ?>">Single SMS</a> / <a href="<?php echo base_url('index.php/rom/group_sms'); ?>">Group SMS</a> / <a href="#"></a></p>
			</div>
		</div>
	</div><br/>
</div>

<?php 

$this->load->view('footer');
 ?>